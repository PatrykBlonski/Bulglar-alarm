#include "klaw.h"

void Klaw_Init(void)
{
	SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;		// Wlaczenie portu A
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;
	PORTA->PCR[SS1] = PORT_PCR_MUX(1);
	PORTA->PCR[SS2] = PORT_PCR_MUX(1);
	PORTA->PCR[SS3] = PORT_PCR_MUX(1);
	PORTA->PCR[SS4] = PORT_PCR_MUX(1);
	PORTB->PCR[R1] = PORT_PCR_MUX(1);
	PORTB->PCR[R2] = PORT_PCR_MUX(1);
	PORTA->PCR[R3] = PORT_PCR_MUX(1);
	PORTA->PCR[R4] = PORT_PCR_MUX(1);
	PORTA->PCR[SS1] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
	PORTA->PCR[SS2] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
	PORTA->PCR[SS3] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
	PORTA->PCR[SS4] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
	PTA->PDDR |= (R3_MASK | R4_MASK);
	PTB->PDDR |= (R1_MASK | R2_MASK);
	PTA->PCOR |= (R3_MASK | R4_MASK);
	PTB->PCOR |= (R1_MASK | R2_MASK);
}
void Klaw_S1_4_Int(void)
{
	PORTA -> PCR[SS1] |= PORT_PCR_IRQC(0xa);		//0x8 - poziom "0"; 0x9 - zbocze narastające; 0xa - zbocze opadające; 0xb - obydwa zbocza
	PORTA -> PCR[SS2] |= PORT_PCR_IRQC(0xa);		
	PORTA -> PCR[SS3] |= PORT_PCR_IRQC(0xa);
	PORTA -> PCR[SS4] |= PORT_PCR_IRQC(0xa);
	NVIC_ClearPendingIRQ(PORTA_IRQn);
	NVIC_EnableIRQ(PORTA_IRQn);
}

void Klaw_Get_Row(uint8_t S) {		//Odczytywanie rzędu na klawiaturze
	#define S_MASK (1<<S)
			PTB->PSOR |= R1_MASK;
			PTB->PSOR |= R2_MASK;
			PTA->PSOR |= R3_MASK;
			PTA->PCOR |= R4_MASK;
			if(!(PTA->PDIR&S_MASK)) {	
				if(!(PTA->PDIR&S_MASK)) {
					row=0;
				}
			}
			PTB->PSOR |= R1_MASK;
			PTB->PSOR |= R2_MASK;
			PTA->PCOR |= R3_MASK;
			PTA->PSOR |= R4_MASK;		
			if(!(PTA->PDIR&S_MASK)) {	
				if(!(PTA->PDIR&S_MASK)) {
					row=1;
				}
			}	
			PTB->PSOR |= R1_MASK;
			PTB->PCOR |= R2_MASK;
			PTA->PSOR |= R3_MASK;
			PTA->PSOR |= R4_MASK;			
			if(!(PTA->PDIR&S_MASK)) {	
				if(!(PTA->PDIR&S_MASK)) {
					row=2;
				}
			}	
			PTB->PCOR |= R1_MASK;
			PTB->PSOR |= R2_MASK;
			PTA->PSOR |= R3_MASK;
			PTA->PSOR |= R4_MASK;	
			if(!(PTA->PDIR&S_MASK)) { 
				if(!(PTA->PDIR&S_MASK)) {
					row=3;
				}
			}
}
unsigned char Klaw_Read(void){		//Odczytyanie znaku z klawiatury
	return klaw[row][col];
}
