#ifndef KLAW_H
#define KLAW_H

#include "MKL05Z4.h"
#define S1_MASK	(1<<7)		// Maska dla klawisza S1
#define S2_MASK	(1<<10)		// Maska dla klawisza S2
#define S3_MASK	(1<<11)		// Maska dla klawisza S3
#define S4_MASK	(1<<12)		// Maska dla klawisza S4
#define R1_MASK	(1<<6)		// Maska dla klawisza R1
#define R2_MASK	(1<<7)		// Maska dla klawisza R2
#define R3_MASK	(1<<9)		// Maska dla klawisza R3
#define R4_MASK	(1<<8)		// Maska dla klawisza R4
#define SS1	7							// Numer bitu dla klawisza S1
#define SS2	10						// Numer bitu dla klawisza S2
#define SS3	11						// Numer bitu dla klawisza S3
#define SS4	12						// Numer bitu dla klawisza S4
#define R1	6						  // Numer bitu dla klawisza R1
#define R2	7							// Numer bitu dla klawisza R2
#define R3	9							// Numer bitu dla klawisza R3
#define R4	8							// Numer bitu dla klawisza R4

extern uint8_t col;
extern uint8_t row;

extern volatile char klaw[4][4];

void Klaw_Init(void);
void Klaw_S1_4_Int(void);
void Klaw_Get_Row(uint8_t);
unsigned char Klaw_Read(void); 

#endif  /* KLAW_H */
