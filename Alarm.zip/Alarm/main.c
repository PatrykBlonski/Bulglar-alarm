/*-------------------------------------------------------------------------
					Technika Mikroprocesorowa 2 - projekt
					Alarm
					autor: Patryk Błoński
					wersja: 4.01.2023r.
----------------------------------------------------------------------------*/
	
#include "MKL05Z4.h"
#include "DAC.h"
#include "klaw.h"
#include "frdm_bsp.h"
#include "lcd1602.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "leds.h"
#include "pit.h"
#include "ADC.h"
#define	ZYXDR_Mask	1<<3	// Maska bitu ZYXDR w rejestrze STATUS
#define DIV_CORE	256  //fclk=256Hz df=0.25Hz
#define MASKA_10BIT	0x03FF

volatile uint8_t S1_press=0;	// "1" - klawisz zostal wcisniety "0" - klawisz "skonsumowany"
volatile uint8_t S2_press=0;
volatile uint8_t S3_press=0;
volatile uint8_t S4_press=0;
volatile char klaw[4][4]={{'7','8','9','A'},{'4','5','6','B'},{'1','2','3',0x20},{'*','0','#',0x20}}; //tabela znaków na klawiaturze
uint8_t col;		//numer kolumny na klawiaturze
uint8_t row;		//numer wiersza na klawiaturze
char pass1[]={0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20}; //tablica znaków do ustawiania hasła		

static uint8_t arrayXYZ[6];
static uint8_t sens;
static uint8_t status;
double X, Y, Z;

uint8_t sekunda=0;			// Licznik przerwan ( do 10)
uint8_t sekunda_OK=0;		// "1"oznacza, ze handler od SysTick zliczyl 10 przerwan, kazde po 0.1s, czyli jedna sekunde
uint8_t sec=0;					//"1" oznacza że handler SysTick będzie zliczał do 1s

uint8_t on_off=255;
int16_t temp;
uint16_t dac;
int16_t Sinus[1024];
uint16_t faza, mod=508;

float adc_volt_coeff = ((float)(((float)2.91) / 4096) );			// Współczynnik korekcji wyniku, w stosunku do napięcia referencyjnego przetwornika
uint8_t wynik_ok=0;
uint16_t temp1;
float	wynik;

void PIT_IRQHandler()
{
	PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF_MASK;		// Skasuj flagę żądania przerwania
	PIT->CHANNEL[0].TCTRL = 0;									// zatrzymaj licznik PIT
}

void ADC0_IRQHandler()
{	
	temp1 = ADC0->R[0];		// Odczyt danej i skasowanie flagi COCO
	if(!wynik_ok)					// Sprawdź, czy wynik skonsumowany przez petlę główną
	{
		wynik = temp1;				// Wyślij nową daną do pętli głównej
		wynik_ok=1;
	}
}
void SysTick_Handler(void)	// Podprogram obslugi przerwania od SysTick'a
{ 
	if(sec){
		sekunda+=1;				// Licz interwaly równe 100ms
	if(sekunda==10)
	{
		sekunda=0;
		sekunda_OK=1;
	}
}else{
	dac=(Sinus[faza]/100)*50+0x0800;					// Przebieg sinusoidalny
	DAC_Load_Trig(dac);
	faza+=mod;		// faza - generator cyfrowej fazy
	faza&=MASKA_10BIT;	// rejestr sterujący przetwornikiem, liczący modulo 1024 (N=10 bitów)
}
}

void PORTA_IRQHandler(void)	// Podprogram obslugi przerwania od klawiszy S1, S2, S3 i S4
{
	uint32_t buf;
	buf=PORTA->ISFR & (S1_MASK | S2_MASK | S3_MASK | S4_MASK);

	switch(buf)
	{
		case S1_MASK: DELAY(10)
			if(!S1_press){
				col=0;
				Klaw_Get_Row(7);	//odczytanie wiersza z pierszej kolumny
				S1_press=1;
			}
			break;
		case S2_MASK:	DELAY(10)
			if(!S2_press){
				col=1;
				Klaw_Get_Row(10);
				S2_press=1;
			}
			break;
		case S3_MASK:	DELAY(10)
			if(!S3_press) {
				col=2;
				Klaw_Get_Row(11);
				S3_press=1;
			}
			break;
		case S4_MASK: DELAY(10)
			if(!S4_press) {
				col=3;
				Klaw_Get_Row(12);
				S4_press=1;
			}
			break;
		default:			break;
	}	
	PTB->PCOR |= R1_MASK | R2_MASK;
	PTA->PCOR |= R3_MASK | R4_MASK;
	PORTA->ISFR |=  S1_MASK | S2_MASK | S3_MASK | S4_MASK;	// Kasowanie wszystkich bitów ISF
	NVIC_ClearPendingIRQ(PORTA_IRQn);
}

void clear_buf(char *buf) {				//usuwanie zawartości bufora do odczytu
	//char disp[]={0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20};
	for(uint8_t i=0;i<strlen(buf);i++){
		buf[i]=0x20;
		//LCD1602_ClearAll();
		//sprintf(disp,"%d",i);
		//LCD1602_SetCursor(0,i);
		//LCD1602_Print(disp);
	}
}

void read(char * buf){			//odczyt znaków z klawiatury
	uint8_t pos=0;
	clear_buf(buf);
	while(1){
		if(buf[pos-1]=='#') break;
		if(S1_press||S2_press||S3_press||S4_press) {
			if(Klaw_Read()=='B'){
				pos--;
				buf[pos]=0x20;
				LCD1602_ClearAll();
				LCD1602_Print(buf);
				S1_press=S2_press=S3_press=S4_press=0;
			}else{
			buf[pos]=Klaw_Read();
			LCD1602_ClearAll();
			LCD1602_Print(buf);
			pos++;
			S1_press=S2_press=S3_press=S4_press=0;
			}
		}
	}
}

void write(char *buf, char *buf1) {			//zapis hasła
	uint8_t i=0;
	while(buf[i-1]!='#') {
		buf1[i]=buf[i];
		i++;
	}
}

void configure(char * buf) {			//konfiguracja alarmu (ustawienie hasła)
while(1){
	LCD1602_ClearAll();
	LCD1602_SetCursor(4,0);
	LCD1602_Print("WELCOME");
	LCD1602_SetCursor(0,1);
	LCD1602_Print("Press * to start");
	while(!(Klaw_Read()=='*'));
	LCD1602_ClearAll();
	LCD1602_Print("Enter password");				//należy wpisać hasło admina "0000" i zatwierdzić #
	S1_press=S2_press=S3_press=S4_press=0;
	read(buf);
	if(strncmp(buf,"0000#",5)==0){
		LCD1602_ClearAll();
		LCD1602_Print("Configure");
		LCD1602_SetCursor(0,1);
		LCD1602_Print("password");				//ustawienie hasła
		read(buf);
		write(buf,pass1);
		while(pass1[4]!='#') {
			LCD1602_ClearAll();
			LCD1602_SetCursor(0,0);
			LCD1602_Print("You can write");
			LCD1602_SetCursor(0,1);
			LCD1602_Print("only 4 digits");
			read(buf);
			write(buf,pass1);
		}
		break;
	}else {
		LCD1602_ClearAll();
		LCD1602_Print("Wrong password");
		DELAY(500)
	}
}
}

int peaks(float *nums) {					//wykrywanie ruchu
	int peaks=0;
	
  for (int i = 1; i < 5; i++) {
    if ((nums[i - 1]-nums[i])>0.0015 && (nums[i + 1]-nums[i])>0.0043)
    {
      peaks++;
		}
	}
	if(peaks)
		return 1;
	else
		return 0;
}

int main (void)
{
	uint8_t armed=0;			//informacja czy alarm jest uzbrojony
	int8_t czas=0;				// Licznik czasu, zliczajacy sekundy od handlera
	char display[]={0x20,0x20,0x20,0x20,0x20};
	char read_buf[]={0x20,0x20,0x20,0x20,0x20};
	float rx[] = {0,0,0,0,0,0};  //tablica przechowująca 6 ostatnich wartości odczytanych z czujnika światła
	const size_t N=6;
	uint8_t	kal_error;
	Klaw_Init();				//Inicjalizaja klawiatury
	Klaw_S1_4_Int();		//Inicjalizaja przerwań na klawiaturze
	LCD1602_Init();		 	// Inicjalizacja wyświetlacza LCD
	LCD1602_Backlight(TRUE);
	LED_Init();					//Inicjalizaja diod led
	PIT_Init();							// Inicjalizacja licznika PIT0
	DAC_Init();		// Inicjalizacja prztwornika C/A
	
	kal_error=ADC_Init();		// Inicjalizacja i kalibracja przetwornika A/C
	if(kal_error)
	{
		while(1);							// Klaibracja się nie powiodła
	}
	
	ADC0->SC1[0] = ADC_SC1_AIEN_MASK | ADC_SC1_ADCH(8);		// Odblokowanie przerwania i wybranie kanału nr 8
	
	I2C_WriteReg(0x1d, 0x2a, 0x0);	// ACTIVE=0 - stan czuwania
	I2C_WriteReg(0x1d, 0xe, 0x0);	 		// Ustaw czulosc zgodnie ze zmienna sens
	I2C_WriteReg(0x1d, 0x2a, 0x1);	 		// ACTIVE=1 - stan aktywny
	
	for(faza=0;faza<1024;faza++)
		Sinus[faza]=(sin((double)faza*0.0061359231515)*2047.0); // Ładowanie 1024-ech sztuk, 12-bitowych próbek funkcji sisnus do tablicy
	faza=0;		// Ustawienie wartości początkowych generatora cyfrowej fazy

	configure(read_buf);
	LCD1602_ClearAll();
	LCD1602_Print("DISARMED");
	while(1)
	{
		if(wynik_ok)		//odczyt danych z czujnika światła
		{
			memmove(&rx[0], &rx[1], (N - 1) * sizeof(rx[0]));
			rx[N-1]=wynik*adc_volt_coeff;
			DELAY(20)
			if(armed){
				if(S1_press||S2_press||S3_press){
						read(read_buf);
						if(strncmp(read_buf,pass1,5)==0){
							armed=0;
							PTB->PSOR|=LED_G_MASK;
							LCD1602_ClearAll();
							LCD1602_Print("DISARMED");
						}
					}
			if(peaks(rx)){
				LCD1602_ClearAll();
				LCD1602_Print("MOTION DETECTED");
				PTB->PSOR|=LED_G_MASK;
				SysTick_Config(SystemCoreClock/DIV_CORE);
				while(1){
					if(S1_press||S2_press||S3_press){
						read(read_buf);
						if(strncmp(read_buf,pass1,5)==0){
							SysTick_Config(1);
							armed=0;
							PTB->PSOR|=LED_R_MASK;
							LCD1602_ClearAll();
							LCD1602_Print("DISARMED");
						break;
						}else{
							LCD1602_ClearAll();
							LCD1602_Print("Wrong password");
							DELAY(500)
							LCD1602_ClearAll();
							LCD1602_Print("MOTION DETECTED");
						}
					}
					PTB->PTOR|=LED_R_MASK;
					DELAY(200)
				}SysTick_Config(1);
			}
			}
			wynik_ok=0;
		}
		I2C_ReadReg(0x1d, 0x0, &status);
		status&=ZYXDR_Mask;
		if(status)	// Czy dane gotowe do odczytu?
		{
		I2C_ReadRegBlock(0x1d, 0x1, 6, arrayXYZ);					//odzcyt danych z akcelerometru
		X=((double)((int16_t)((arrayXYZ[0]<<8)|arrayXYZ[1])>>2)/(4096>>0));
		Y=((double)((int16_t)((arrayXYZ[2]<<8)|arrayXYZ[3])>>2)/(4096>>0));
		Z=((double)((int16_t)((arrayXYZ[4]<<8)|arrayXYZ[5])>>2)/(4096>>0));
			if((fabs(X)>0.3)||(fabs(Y)>0.3)||(fabs(Z)>1.3))
			{
				LCD1602_ClearAll();
				LCD1602_Print("ALARM WAS MOVED");
				SysTick_Config(SystemCoreClock/DIV_CORE);
				while(1){
					if(S1_press||S2_press||S3_press){
						read(read_buf);
						if(strncmp(read_buf,pass1,5)==0){
							SysTick_Config(1);
							PTB->PSOR|=LED_R_MASK;
							LCD1602_ClearAll();
							LCD1602_Print("DISARMED");
						break;
						}else{
							LCD1602_ClearAll();
							LCD1602_Print("Wrong password");
							DELAY(500)
							LCD1602_ClearAll();
							LCD1602_Print("ALARM WAS MOVED");
						}
					}
					PTB->PTOR|=LED_R_MASK;
					DELAY(200)
				}SysTick_Config(1);
			}
			status=0;
		}
		if(S4_press&&Klaw_Read()=='A') {			//uzbrojenie alarmu, odliczanie do włączenia
			czas=10;
			LCD1602_ClearAll();
			sec=1;
			SysTick_Config(SystemCoreClock/10);
			while(czas>=0){
				if(sekunda_OK){
					LCD1602_ClearAll();
					sprintf(display,"%d",czas);
					LCD1602_Print(display);
					czas--;
					sekunda_OK=0;
				}
			}
			SysTick_Config(1);
			sec=0;
			armed=1;
			LCD1602_ClearAll();
			LCD1602_Print("ARMED");
			S4_press=0;
			PTB->PCOR|=LED_G_MASK;
		}
		if(S1_press&&Klaw_Read()=='*'){ 					//zmiana hasła, należy wpisać "*0000#"
			read(read_buf);
			if(strncmp(read_buf,"*0000#",6)==0){
				LCD1602_ClearAll();
				LCD1602_Print("Enter new");
				LCD1602_SetCursor(0,1);
				LCD1602_Print("password");
				read(read_buf);
				write(read_buf,pass1);
				while(pass1[4]!='#') {
					LCD1602_ClearAll();
					LCD1602_SetCursor(0,0);
					LCD1602_Print("You can write");
					LCD1602_SetCursor(0,1);
					LCD1602_Print("only 4 digits");
					read(read_buf);
					write(read_buf,pass1);
				}
				LCD1602_ClearAll();
				LCD1602_Print("DISARMED");
			}else {
				LCD1602_ClearAll();
				LCD1602_Print("Wrong passoword");
				DELAY(100)
				LCD1602_ClearAll();
				LCD1602_Print("DISARMED");
			}
		}
		S1_press=S2_press=S3_press=S4_press=0;
}
}
	

